package br.dev.cityreport.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import br.dev.cityreport.data.local.dao.CategoryDao // Crie este DAO
import br.dev.cityreport.data.local.dao.ProblemDao  // Crie este DAO
import br.dev.cityreport.data.local.dao.UserDao
import br.dev.cityreport.data.model.Category
import br.dev.cityreport.data.model.Problem
import br.dev.cityreport.data.model.User

@Database(entities = [User::class, Problem::class, Category::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun problemDao(): ProblemDao
    abstract fun categoryDao(): CategoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "city_report_db"
                )
                    .addMigrations(AppMigrations.getMigrations()[0]) // Se você tiver migrações futuras
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}