package br.dev.cityreport

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.lint.Names.Runtime.LaunchedEffect
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import br.dev.cityreport.data.local.AppDatabase
import br.dev.cityreport.data.model.Category
import br.dev.cityreport.data.model.Problem
import br.dev.cityreport.data.repository.CategoryRepository
import br.dev.cityreport.data.repository.ProblemRepository
import br.dev.cityreport.data.repository.UserRepository
import br.dev.cityreport.data.services.AuthService
import br.dev.cityreport.data.services.CategoryService
import br.dev.cityreport.data.services.ProblemService
import br.dev.cityreport.ui.theme.CityReportTheme
import br.dev.cityreport.views.LoginScreen
import br.dev.cityreport.views.ProblemDetailScreen
import br.dev.cityreport.views.ProblemListScreen
import br.dev.cityreport.views.RegisterScreen
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Solicitar permissão de notificação (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val requestPermissionLauncher =
                    registerForActivityResult(ActivityResultContracts.RequestPermission()) {
                            isGranted: Boolean ->
                        // Pode exibir um Toast ou logar se desejar
                    }
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val db = AppDatabase.getDatabase(this)
        val userRepository = UserRepository(db.userDao())
        val problemRepository = ProblemRepository(db.problemDao())
        val categoryRepository = CategoryRepository(db.categoryDao())
        val authService = AuthService(userRepository)
        val problemService = ProblemService(problemRepository)
        val categoryService = CategoryService(categoryRepository)

        // Adicionar dados de exemplo
        lifecycleScope.launch { setupSampleData(db, userRepository, problemRepository) }

        setContent {
            val navController = rememberNavController()
            var loginResult by remember { mutableStateOf<String?>(null) }
            CityReportTheme {
                NavHost(navController = navController, startDestination = "login") {
                    composable("login") {
                        LoginScreen(
                                onLoginClicked = { user, pass ->
                                    lifecycleScope.launch {
                                        val success = authService.login(user, pass)
                                        if (success) {
                                            loginResult = "Login realizado com sucesso!"
                                            // Navegar para tela de problemas após login
                                            // bem-sucedido
                                            kotlinx.coroutines.delay(1000)
                                            navController.navigate("problems") {
                                                popUpTo("login") { inclusive = true }
                                            }
                                        } else {
                                            loginResult = "Usuário ou senha inválidos."
                                        }
                                    }
                                },
                                onRegisterClicked = { navController.navigate("register") },
                                loginResult = loginResult
                        )
                    }
                    composable("register") {
                        var registerResult by remember { mutableStateOf<String?>(null) }
                        RegisterScreen(
                                onRegisterClicked = { name, email, password ->
                                    lifecycleScope.launch {
                                        val success = authService.register(name, email, password)
                                        registerResult =
                                                if (success) {
                                                    "Cadastro realizado com sucesso!"
                                                } else {
                                                    "Erro ao cadastrar. Tente outro e-mail."
                                                }
                                        // Se cadastro foi bem-sucedido, navegar para login após 2
                                        // segundos
                                        if (success) {
                                            kotlinx.coroutines.delay(2000)
                                            navController.navigate("login") {
                                                popUpTo("login") { inclusive = true }
                                            }
                                        }
                                    }
                                },
                                onBackToLoginClicked = {
                                    navController.navigate("login") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                },
                                registerResult = registerResult
                        )
                    }
                    composable("problems") {
                        ProblemListScreen(
                                problemService = problemService,
                                authService = authService,
                                categoryService = categoryService,
                                onProblemClick = { problem ->
                                    navController.navigate("problemDetail/${problem.id}")
                                }
                        )
                    }
                    composable("problemDetail/{problemId}") { backStackEntry ->
                        val problemId =
                                backStackEntry.arguments?.getString("problemId")?.toLongOrNull()
                        val currentUserId = authService.getCurrentUser()?.id?.toLong() ?: -1

                        var problem by remember { mutableStateOf<Problem?>(null) }
                        var category by remember { mutableStateOf<Category?>(null) }

                        LaunchedEffect(problemId) {
                            if (problemId != null) {
                                problem = problemService.findProblemById(problemId)
                                if (problem != null) {
                                    category =
                                            categoryService.getCategoryById(
                                                    problem!!.categoriaId.toLong()
                                            )
                                }
                            }
                        }

                        if (problem != null) {
                            ProblemDetailScreen(
                                    problem = problem!!,
                                    onStatusChange = { newStatus ->
                                        lifecycleScope.launch {
                                            problemService.updateProblemStatus(problemId, newStatus)
                                            problem = problemService.findProblemById(problemId!!)
                                        }
                                    },
                                    onBack = { navController.popBackStack() },
                                    categoriaAtual = category
                            )
                        } else {
                            Text("Problema não encontrado")
                        }
                    }
                }
            }
        }
    }

    suspend fun setupSampleData(
            db: AppDatabase,
            userRepository: UserRepository,
            problemRepository: ProblemRepository
    ) {
        try {
            // Criar categorias de exemplo
            val categoryDao = db.categoryDao()
            val categories =
                    listOf(
                            Category(
                                    id = 1,
                                    nome = "Iluminação",
                                    descricao = "Problemas com iluminação pública"
                            ),
                            Category(
                                    id = 2,
                                    nome = "Buraco na Rua",
                                    descricao = "Buracos e problemas no asfalto"
                            ),
                            Category(
                                    id = 3,
                                    nome = "Limpeza",
                                    descricao = "Problemas de limpeza urbana"
                            ),
                            Category(
                                    id = 4,
                                    nome = "Sinalização",
                                    descricao = "Problemas com placas e sinalização"
                            )
                    )

            categories.forEach { category ->
                try {
                    categoryDao.insertCategory(category)
                } catch (e: Exception) {
                    // Categoria já existe, ignorar
                }
            }
        } catch (e: Exception) {
            // Log do erro se necessário
            e.printStackTrace()
        }
    }
}
