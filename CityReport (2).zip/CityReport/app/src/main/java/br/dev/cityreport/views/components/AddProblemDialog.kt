package br.dev.cityreport.views.components

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Location
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.FileProvider
import br.dev.cityreport.data.model.Category
import br.dev.cityreport.data.model.Problem
import br.dev.cityreport.data.services.CategoryService
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.launch

@SuppressLint("DefaultLocale")
@OptIn(ExperimentalPermissionsApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AddProblemDialog(
        isVisible: Boolean,
        categoryService: CategoryService,
        userId: Int,
        onDismiss: () -> Unit,
        onConfirm: (Problem) -> Unit
) {
        var description by remember { mutableStateOf("") }
        var selectedCategory by remember { mutableStateOf<Category?>(null) }
        var categories by remember { mutableStateOf<List<Category>>(emptyList()) }
        var latitude by remember { mutableStateOf<Double?>(null) }
        var longitude by remember { mutableStateOf<Double?>(null) }
        var isLoadingLocation by remember { mutableStateOf(false) }
        var locationError by remember { mutableStateOf<String?>(null) }
        var expandedDropdown by remember { mutableStateOf(false) }
        var fotos by remember { mutableStateOf<List<ByteArray>>(emptyList()) }
        val context = LocalContext.current
        val lifecycleOwner = LocalLifecycleOwner.current
        val keyboardController = LocalSoftwareKeyboardController.current
        // Launchers para galeria e câmera
        val galleryLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri?
                        ->
                        uri?.let {
                                val bitmap =
                                        MediaStore.Images.Media.getBitmap(
                                                context.contentResolver,
                                                it
                                        )
                                val stream = ByteArrayOutputStream()
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                                fotos = fotos + stream.toByteArray()
                        }
                }
        var cameraImageUri by remember { mutableStateOf<Uri?>(null) }
        val cameraLauncher =
                rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) {
                        success: Boolean ->
                        if (success && cameraImageUri != null) {
                                val bitmap =
                                        MediaStore.Images.Media.getBitmap(
                                                context.contentResolver,
                                                cameraImageUri
                                        )
                                val stream = ByteArrayOutputStream()
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                                fotos = fotos + stream.toByteArray()
                        }
                }
        // Estado das permissões de localização
        val locationPermissionsState =
                rememberMultiplePermissionsState(
                        listOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                        )
                )

        val cameraPermissionLauncher =
                rememberLauncherForActivityResult(
                        contract = ActivityResultContracts.RequestPermission(),
                        onResult = { isGranted ->
                                if (isGranted) {
                                        cameraLauncher.launch(cameraImageUri)
                                } else
                                        Toast.makeText(
                                                        context,
                                                        "Permissão da câmera negada",
                                                        Toast.LENGTH_SHORT
                                                )
                                                .show()
                        }
                )

        // Carrega categorias quando o dialog é aberto
        LaunchedEffect(isVisible) {
                if (isVisible) {
                        try {
                                categories = categoryService.getAllCategories()
                        } catch (e: Exception) {
                                // Handle error
                        }
                }
        }

        if (isVisible) {
                Dialog(
                        onDismissRequest = onDismiss,
                        properties =
                                DialogProperties(
                                        dismissOnBackPress = true,
                                        dismissOnClickOutside = true,
                                        usePlatformDefaultWidth = false
                                )
                ) {
                        Card(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
                        ) {
                                Column(
                                        modifier =
                                                Modifier.fillMaxWidth()
                                                        .padding(24.dp)
                                                        .verticalScroll(rememberScrollState()),
                                        verticalArrangement = Arrangement.spacedBy(16.dp)
                                ) {
                                        // Título
                                        Text(
                                                text = "Reportar Problema",
                                                style = MaterialTheme.typography.headlineSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurface
                                        )

                                        // Dropdown para categoria
                                        ExposedDropdownMenuBox(
                                                expanded = expandedDropdown,
                                                onExpandedChange = {
                                                        expandedDropdown = !expandedDropdown
                                                }
                                        ) {
                                                OutlinedTextField(
                                                        value = selectedCategory?.nome ?: "",
                                                        onValueChange = {},
                                                        readOnly = true,
                                                        label = { Text("Categoria") },
                                                        placeholder = {
                                                                Text("Selecione uma categoria")
                                                        },
                                                        trailingIcon = {
                                                                ExposedDropdownMenuDefaults
                                                                        .TrailingIcon(
                                                                                expanded =
                                                                                        expandedDropdown
                                                                        )
                                                        },
                                                        modifier =
                                                                Modifier.fillMaxWidth().menuAnchor()
                                                )

                                                ExposedDropdownMenu(
                                                        expanded = expandedDropdown,
                                                        onDismissRequest = {
                                                                expandedDropdown = false
                                                        }
                                                ) {
                                                        categories.forEach { category ->
                                                                DropdownMenuItem(
                                                                        text = {
                                                                                Column {
                                                                                        Text(
                                                                                                text =
                                                                                                        category.nome,
                                                                                                fontWeight =
                                                                                                        FontWeight
                                                                                                                .Medium
                                                                                        )
                                                                                        Text(
                                                                                                text =
                                                                                                        category.descricao,
                                                                                                style =
                                                                                                        MaterialTheme
                                                                                                                .typography
                                                                                                                .bodySmall,
                                                                                                color =
                                                                                                        MaterialTheme
                                                                                                                .colorScheme
                                                                                                                .onSurfaceVariant
                                                                                        )
                                                                                }
                                                                        },
                                                                        onClick = {
                                                                                selectedCategory =
                                                                                        category
                                                                                expandedDropdown =
                                                                                        false
                                                                        }
                                                                )
                                                        }
                                                }
                                        }

                                        // Campo de descrição
                                        OutlinedTextField(
                                                value = description,
                                                onValueChange = { description = it },
                                                label = { Text("Descrição do Problema") },
                                                placeholder = {
                                                        Text(
                                                                "Descreva detalhadamente o problema encontrado..."
                                                        )
                                                },
                                                modifier = Modifier.fillMaxWidth(),
                                                minLines = 3,
                                                maxLines = 5,
                                                keyboardOptions =
                                                        KeyboardOptions(
                                                                keyboardType = KeyboardType.Text,
                                                                imeAction = ImeAction.Done
                                                        ),
                                                keyboardActions =
                                                        KeyboardActions(
                                                                onDone = {
                                                                        keyboardController?.hide()
                                                                }
                                                        )
                                        )

                                        // Seção de localização
                                        Card(
                                                modifier = Modifier.fillMaxWidth(),
                                                colors =
                                                        CardDefaults.cardColors(
                                                                containerColor =
                                                                        MaterialTheme.colorScheme
                                                                                .surfaceVariant
                                                                                .copy(alpha = 0.3f)
                                                        )
                                        ) {
                                                Column(
                                                        modifier = Modifier.padding(16.dp),
                                                        verticalArrangement =
                                                                Arrangement.spacedBy(12.dp)
                                                ) {
                                                        Row(
                                                                verticalAlignment =
                                                                        Alignment.CenterVertically,
                                                                horizontalArrangement =
                                                                        Arrangement.spacedBy(8.dp)
                                                        ) {
                                                                Icon(
                                                                        imageVector =
                                                                                Icons.Default
                                                                                        .LocationOn,
                                                                        contentDescription =
                                                                                "Localização",
                                                                        tint =
                                                                                MaterialTheme
                                                                                        .colorScheme
                                                                                        .primary
                                                                )
                                                                Text(
                                                                        text = "Localização",
                                                                        style =
                                                                                MaterialTheme
                                                                                        .typography
                                                                                        .titleMedium,
                                                                        fontWeight =
                                                                                FontWeight.Medium
                                                                )
                                                        }

                                                        // Mapa interativo
                                                        val markerPosition =
                                                                remember(latitude to longitude) {
                                                                        LatLng(
                                                                                latitude
                                                                                        ?: -23.5505,
                                                                                longitude
                                                                                        ?: -46.6333
                                                                        ) // SP como default
                                                                }
                                                        val cameraPositionState =
                                                                rememberCameraPositionState {
                                                                        position =
                                                                                com.google.android
                                                                                        .gms.maps
                                                                                        .model
                                                                                        .CameraPosition
                                                                                        .fromLatLngZoom(
                                                                                                markerPosition,
                                                                                                16f
                                                                                        )
                                                                }
                                                        val markerState =
                                                                rememberMarkerState(
                                                                        position = markerPosition
                                                                )

                                                        // Atualiza a posição da câmera quando
                                                        // latitude/longitude mudam
                                                        LaunchedEffect(latitude, longitude) {
                                                                if (latitude != null &&
                                                                                longitude != null
                                                                ) {
                                                                        val newLatLng =
                                                                                LatLng(
                                                                                        latitude!!,
                                                                                        longitude!!
                                                                                )
                                                                    cameraPositionState
                                                                        .animate(
                                                                            CameraUpdateFactory
                                                                                .newLatLngZoom(
                                                                                    newLatLng,
                                                                                    16f
                                                                                )
                                                                        )
                                                                        markerState.position =
                                                                                newLatLng
                                                                }
                                                        }

                                                        // Wrapper para evitar scroll durante
                                                        // interação com o mapa
                                                        Box(
                                                                modifier =
                                                                        Modifier.fillMaxWidth()
                                                                                .height(220.dp)
                                                                                .pointerInput(
                                                                                        Unit
                                                                                ) {
                                                                                        awaitPointerEventScope {
                                                                                                while (true) {
                                                                                                        val event =
                                                                                                                awaitPointerEvent()
                                                                                                        if (event.changes
                                                                                                                        .any {
                                                                                                                                it.pressed
                                                                                                                        }
                                                                                                        ) {

                                                                                                        }
                                                                                                }
                                                                                        }
                                                                                }
                                                        ) {
                                                                GoogleMap(
                                                                        modifier =
                                                                                Modifier.matchParentSize(),
                                                                        cameraPositionState =
                                                                                cameraPositionState,
                                                                        onMapClick = { latLng ->
                                                                                latitude =
                                                                                        latLng.latitude
                                                                                longitude =
                                                                                        latLng.longitude
                                                                                markerState
                                                                                        .position =
                                                                                        latLng
                                                                        }
                                                                ) {
                                                                        Marker(
                                                                                state = markerState,
                                                                                draggable = true,
                                                                        )
                                                                }
                                                        }
                                                        // Exibe coordenadas
                                                        if (latitude != null && longitude != null) {
                                                                Text(
                                                                        text =
                                                                                "Coordenadas: ${
                                            String.format(
                                                "%.6f",
                                                latitude
                                            )
                                        }, ${String.format("%.6f", longitude)}",
                                                                        style =
                                                                                MaterialTheme
                                                                                        .typography
                                                                                        .bodyMedium,
                                                                        fontWeight =
                                                                                FontWeight.Medium
                                                                )
                                                        }

                                                        Button(
                                                                onClick = {
                                                                        if (locationPermissionsState
                                                                                        .allPermissionsGranted
                                                                        ) {
                                                                                getCurrentLocation(
                                                                                        context =
                                                                                                context,
                                                                                        onLocationResult = {
                                                                                                lat,
                                                                                                lng
                                                                                                ->
                                                                                                latitude =
                                                                                                        lat
                                                                                                longitude =
                                                                                                        lng
                                                                                                isLoadingLocation =
                                                                                                        false
                                                                                                locationError =
                                                                                                        null
                                                                                                val newLatLng =
                                                                                                        LatLng(
                                                                                                                lat,
                                                                                                                lng
                                                                                                        )
                                                                                                // Corrige: chama animate dentro de launch
                                                                                                cameraPositionState
                                                                                                        .move(
                                                                                                                CameraUpdateFactory
                                                                                                                        .newLatLngZoom(
                                                                                                                                newLatLng,
                                                                                                                                16f
                                                                                                                        )
                                                                                                        )
                                                                                                markerState
                                                                                                        .position =
                                                                                                        newLatLng
                                                                                        },
                                                                                        onError = {
                                                                                                error
                                                                                                ->
                                                                                                locationError =
                                                                                                        error
                                                                                                isLoadingLocation =
                                                                                                        false
                                                                                        }
                                                                                )
                                                                                isLoadingLocation =
                                                                                        true
                                                                                locationError = null
                                                                        } else {
                                                                                locationPermissionsState
                                                                                        .launchMultiplePermissionRequest()
                                                                        }
                                                                },
                                                                modifier = Modifier.fillMaxWidth(),
                                                                enabled = !isLoadingLocation
                                                        ) {
                                                                Icon(
                                                                        imageVector =
                                                                                Icons.Default
                                                                                        .LocationOn,
                                                                        contentDescription = null,
                                                                        modifier =
                                                                                Modifier.size(18.dp)
                                                                )
                                                                Spacer(
                                                                        modifier =
                                                                                Modifier.width(8.dp)
                                                                )
                                                                Text(
                                                                        if (locationPermissionsState
                                                                                        .allPermissionsGranted
                                                                        ) {
                                                                                "Obter Localização Atual"
                                                                        } else {
                                                                                "Permitir Acesso à Localização"
                                                                        }
                                                                )
                                                        }
                                                }
                                        }

                                        // Seção de fotos
                                        Text("Fotos", fontWeight = FontWeight.Medium)
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                fotos.forEach { foto ->
                                                        val bitmap =
                                                                BitmapFactory.decodeByteArray(
                                                                        foto,
                                                                        0,
                                                                        foto.size
                                                                )
                                                        Image(
                                                                bitmap = bitmap.asImageBitmap(),
                                                                contentDescription =
                                                                        "Foto adicionada",
                                                                modifier = Modifier.size(64.dp)
                                                        )
                                                }
                                                IconButton(
                                                        onClick = {
                                                                galleryLauncher.launch("image/*")
                                                        }
                                                ) {
                                                        Icon(
                                                                Icons.Default.Add,
                                                                contentDescription =
                                                                        "Adicionar da galeria"
                                                        )
                                                }
                                                IconButton(
                                                        onClick = {
                                                                // Criar arquivo temporário para a
                                                                // foto
                                                                val file =
                                                                        File.createTempFile(
                                                                                "camera_photo",
                                                                                ".jpg",
                                                                                context.cacheDir
                                                                        )
                                                                cameraImageUri =
                                                                        FileProvider.getUriForFile(
                                                                                context,
                                                                                context.packageName +
                                                                                        ".provider",
                                                                                file
                                                                        )
                                                                cameraPermissionLauncher.launch(
                                                                        Manifest.permission.CAMERA
                                                                )
                                                        }
                                                ) {
                                                        Icon(
                                                                Icons.Filled.CameraAlt,
                                                                contentDescription = "Tirar foto"
                                                        )
                                                }
                                        }

                                        // Botões de ação
                                        Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                                OutlinedButton(
                                                        onClick = onDismiss,
                                                        modifier = Modifier.weight(1f)
                                                ) { Text("Cancelar") }

                                                Button(
                                                        onClick = {
                                                                if (isFormValid(
                                                                                description,
                                                                                selectedCategory,
                                                                                latitude,
                                                                                longitude
                                                                        )
                                                                ) {
                                                                        val currentDateTime =
                                                                                SimpleDateFormat(
                                                                                                "yyyy-MM-dd HH:mm:ss",
                                                                                                Locale.getDefault()
                                                                                        )
                                                                                        .format(
                                                                                                Date()
                                                                                        )

                                                                        val problem =
                                                                                Problem(
                                                                                        categoriaId =
                                                                                                selectedCategory!!
                                                                                                        .id,
                                                                                        usuarioId =
                                                                                                userId,
                                                                                        descricao =
                                                                                                description
                                                                                                        .trim(),
                                                                                        fotos =
                                                                                                fotos,
                                                                                        latitude =
                                                                                                latitude!!,
                                                                                        longitude =
                                                                                                longitude!!,
                                                                                        dataHora =
                                                                                                currentDateTime,
                                                                                        status =
                                                                                                "aberto"
                                                                                )

                                                                        onConfirm(problem)
                                                                }
                                                        },
                                                        modifier = Modifier.weight(1f),
                                                        enabled =
                                                                isFormValid(
                                                                        description,
                                                                        selectedCategory,
                                                                        latitude,
                                                                        longitude
                                                                )
                                                ) { Text("Reportar") }
                                        }
                                }
                        }
                }
        }
}

private fun isFormValid(
        description: String,
        selectedCategory: Category?,
        latitude: Double?,
        longitude: Double?
): Boolean {
        return description.trim().isNotEmpty() &&
                selectedCategory != null &&
                latitude != null &&
                longitude != null
}

private fun getCurrentLocation(
        context: Context,
        onLocationResult: (Double, Double) -> Unit,
        onError: (String) -> Unit
) {
        try {
                val fusedLocationClient = LocationServices.getFusedLocationProviderClient(context)
                fusedLocationClient.lastLocation
                        .addOnSuccessListener { location: Location? ->
                                if (location != null) {
                                        onLocationResult(location.latitude, location.longitude)
                                } else {
                                        onError(
                                                "Não foi possível obter a localização. Verifique se o GPS está ativado."
                                        )
                                }
                        }
                        .addOnFailureListener { exception ->
                                onError("Erro ao obter localização: ${exception.message}")
                        }
        } catch (e: SecurityException) {
                onError("Permissão de localização negada")
        } catch (e: Exception) {
                onError("Erro inesperado: ${e.message}")
        }
}
