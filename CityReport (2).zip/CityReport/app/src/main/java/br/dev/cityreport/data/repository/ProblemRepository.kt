package br.dev.cityreport.data.repository;


import br.dev.cityreport.data.local.dao.ProblemDao;
import br.dev.cityreport.data.model.Problem

class ProblemRepository(private val problemDao: ProblemDao) {
    suspend fun registerProblem(problem: Problem): Result<Long> {
        return try {
            val id = problemDao.insertProblem(problem)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun findAllProblemsByUsuarioId(userId: Long): List<Problem> {
        return problemDao.findAllProblemsByUsuarioId(userId)
    }

    suspend fun updateProblem(problem: Problem): Result<Int> {
        return try {
            val rowsUpdated = problemDao.updateProblem(problem)
            Result.success(rowsUpdated)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun findProblemById(lng: Long): Problem? {
        return problemDao.findProblemById(lng)
    }

    suspend fun updateProblemStatus(id: Long?, status: String) {
        if(id==null) return;
        val problem = findProblemById(id);
        if(problem!=null){
            problem.status = status;
            updateProblem(problem);
        }
    }
}