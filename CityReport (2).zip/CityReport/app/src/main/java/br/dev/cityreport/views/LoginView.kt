package br.dev.cityreport.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import br.dev.cityreport.ui.theme.CityReportTheme // Importe seu tema

@Composable
fun LoginScreen(
        onLoginClicked: (String, String) -> Unit,
        onRegisterClicked: () -> Unit,
        loginResult: String? = null
) {
    var username by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var passwordVisible by rememberSaveable { mutableStateOf(false) }

    Column(
            modifier =
                    Modifier.fillMaxSize()
                            .background(MaterialTheme.colorScheme.background)
                            .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
                text = "Login",
                style =
                        MaterialTheme.typography.headlineMedium.copy(
                                Color.White
                        ), // Use headlineMedium para um título maior
                modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
                value = username,
                onValueChange = { username = it },
                label = { Text("Usuário") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                singleLine = true
        )

        OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Senha") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                singleLine = true,
                visualTransformation =
                        if (passwordVisible) VisualTransformation.None
                        else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        )

        // Exibe o resultado do login, se disponível
        if (loginResult != null) {
            Text(
                    text = loginResult,
                    color = if (loginResult.contains("sucesso")) Color(0xFF388E3C) else Color.Red,
                    modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        Button(
                onClick = { onLoginClicked(username, password) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                enabled =
                        username.isNotBlank() &&
                                password.isNotBlank() // Habilita o botão apenas se os campos
                // estiverem preenchidos
                ) { Text("Entrar") }

        TextButton(onClick = { onRegisterClicked() }, modifier = Modifier.padding(top = 8.dp)) {
            Text("Criar conta")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    CityReportTheme(darkTheme = true) {
        LoginScreen(
                onLoginClicked = { user, pass -> println("Usuário: $user, Senha: $pass") },
                onRegisterClicked = { /* Lógica de registro */}
        )
    }
}
