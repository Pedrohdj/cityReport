package br.dev.cityreport.data.model

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey
import androidx.room.TypeConverters

@Entity(
        tableName = "problemas",
        foreignKeys =
                [
                        ForeignKey(
                                entity = User::class,
                                parentColumns = ["id"],
                                childColumns = ["usuario_id"],
                                onDelete = ForeignKey.CASCADE // Ou outra ação desejada
                        ),
                        ForeignKey(
                                entity = Category::class,
                                parentColumns = ["id"],
                                childColumns = ["categoria_id"],
                                onDelete = ForeignKey.RESTRICT // Ou outra ação desejada
                        )]
)
@TypeConverters(PhotoListConverter::class)
data class Problem(
        @PrimaryKey(autoGenerate = true) val id: Int = 0,
        @ColumnInfo(name = "categoria_id", index = true) val categoriaId: Int,
        @ColumnInfo(name = "usuario_id", index = true) val usuarioId: Int,
        val descricao: String,
        val fotos: List<ByteArray> = emptyList(), // Suporte a múltiplas fotos
        val latitude: Double,
        val longitude: Double,
        @ColumnInfo(name = "data_hora")
        val dataHora: String, // Considere usar Long para timestamp e TypeConverters
        var status: String
) {
    // Necessário para Room lidar com ByteArray e evitar erros de equals/hashCode
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as Problem

        if (id != other.id) return false
        if (categoriaId != other.categoriaId) return false
        if (usuarioId != other.usuarioId) return false
        if (descricao != other.descricao) return false
        if (fotos != other.fotos) return false
        if (latitude != other.latitude) return false
        if (longitude != other.longitude) return false
        if (dataHora != other.dataHora) return false
        if (status != other.status) return false

        return true
    }

    override fun hashCode(): Int {
        var result = id
        result = 31 * result + categoriaId
        result = 31 * result + usuarioId
        result = 31 * result + descricao.hashCode()
        result = 31 * result + fotos.hashCode()
        result = 31 * result + latitude.hashCode()
        result = 31 * result + longitude.hashCode()
        result = 31 * result + dataHora.hashCode()
        result = 31 * result + status.hashCode()
        return result
    }
}
