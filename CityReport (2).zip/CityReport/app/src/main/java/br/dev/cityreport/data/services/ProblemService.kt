package br.dev.cityreport.data.services

import br.dev.cityreport.data.model.Problem
import br.dev.cityreport.data.repository.ProblemRepository

class ProblemService(private val problemRepository: ProblemRepository) {
    suspend fun registerProblem(problem: Problem): Result<Long> {
        return problemRepository.registerProblem(problem)
    }

    suspend fun findAllProblemsByUsuarioId(userId: Long): List<Problem> {
        return problemRepository.findAllProblemsByUsuarioId(userId)
    }

    suspend fun findProblemById(problemId: Long): Problem? {
        return problemRepository.findProblemById(problemId)
    }

    suspend fun updateProblem(problem: Problem): Result<Int> {
        return problemRepository.updateProblem(problem)
    }

    suspend fun updateProblemStatus(id: Long?, string: String) {
        problemRepository.updateProblemStatus(id, string)
    }

}