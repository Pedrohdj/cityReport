package br.dev.cityreport.data.repository

import br.dev.cityreport.data.local.dao.CategoryDao
import br.dev.cityreport.data.model.Category

class CategoryRepository(private val categoryDao: CategoryDao) {
    
    suspend fun insertCategory(category: Category): Result<Long> {
        return try {
            val id = categoryDao.insertCategory(category)
            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
    
    suspend fun getAllCategories(): List<Category> {
        return categoryDao.findAllCategories()
    }
    
    suspend fun getCategoryById(id: Long): Category? {
        val categories = categoryDao.findAllCategories()
        return categories.find { it.id.toLong() == id }
    }
}
