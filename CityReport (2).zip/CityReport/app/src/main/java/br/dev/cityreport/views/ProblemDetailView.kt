package br.dev.cityreport.views

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.graphics.BitmapFactory
import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import br.dev.cityreport.data.model.Category
import br.dev.cityreport.data.model.Problem
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("MissingPermission")
@Composable
fun ProblemDetailScreen(
        problem: Problem,
        statusOptions: List<String> = listOf("aberto", "em_andamento", "resolvido", "fechado"),
        onStatusChange: (String) -> Unit,
        categoriaAtual: Category?,
        onBack: () -> Unit
) {
    var selectedStatus by remember { mutableStateOf(problem.status) }
    val context = LocalContext.current
    // Notificação: criar canal se necessário
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel =
                    NotificationChannel(
                            "status_update_channel",
                            "Atualização de Reclamação",
                            NotificationManager.IMPORTANCE_DEFAULT
                    )
            val notificationManager = context.getSystemService(NotificationManager::class.java)
            notificationManager.createNotificationChannel(channel)
        }
    }
    val position = LatLng(problem.latitude, problem.longitude)
    val cameraPositionState = rememberCameraPositionState(key = null) {}
    val problemMarkerState = rememberMarkerState(position = position)
    LaunchedEffect(Unit) {
        cameraPositionState.position = CameraPosition.fromLatLngZoom(position, 15f)
    }

    Scaffold(
            topBar = {
                TopAppBar(
                        title = { Text("Detalhes do Problema", fontWeight = FontWeight.Bold) },
                        navigationIcon = {
                            IconButton(onClick = onBack) {
                                Icon(
                                        Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Voltar"
                                )
                            }
                        }
                )
            }
    ) { innerPadding ->
        Column(
                modifier = Modifier.fillMaxSize().padding(innerPadding).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(text = problem.descricao, style = MaterialTheme.typography.titleMedium)
            Text(
                    text = "Categoria: ${categoriaAtual?.descricao?: "Categoria não encontrada"}",
                    style = MaterialTheme.typography.bodyMedium
            )
            Text(text = "Data: ${problem.dataHora}", style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(8.dp))
            // Mapa
            GoogleMap(
                    modifier = Modifier.fillMaxWidth().height(220.dp),
                    cameraPositionState = cameraPositionState
            ) { Marker(state = problemMarkerState, title = "Local do Problema") }
            Spacer(modifier = Modifier.height(8.dp))
            // Dropdown de status
            Text("Status:", fontWeight = FontWeight.Medium)
            var expanded by remember { mutableStateOf(false) }

            ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
            ) {
                OutlinedTextField(
                        value = statusLabel(selectedStatus),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Status do Problema") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                        },
                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                        colors = ExposedDropdownMenuDefaults.textFieldColors()
                )

                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    statusOptions.forEach { status ->
                        DropdownMenuItem(
                                text = { Text(statusLabel(status)) },
                                onClick = {
                                    selectedStatus = status
                                    expanded = false
                                    onStatusChange(status)
                                    // Notificação na barra do sistema
                                    val notification =
                                            NotificationCompat.Builder(
                                                            context,
                                                            "status_update_channel"
                                                    )
                                                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                                                    .setContentTitle("Reclamação atualizada")
                                                    .setContentText(
                                                            "O status da reclamação foi alterado para: ${statusLabel(status)}"
                                                    )
                                                    .setPriority(
                                                            NotificationCompat.PRIORITY_DEFAULT
                                                    )
                                                    .build()
                                    NotificationManagerCompat.from(context)
                                            .notify(problem.id, notification)
                                }
                        )
                    }
                }
            }

            // Fotos
            if (problem.fotos.isNotEmpty()) {
                Text("Fotos anexadas:", fontWeight = FontWeight.Medium)
                Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    problem.fotos.forEach { foto ->
                        val bitmap = BitmapFactory.decodeByteArray(foto, 0, foto.size)
                        Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "Foto do problema",
                                modifier = Modifier.size(96.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

private fun statusLabel(status: String): String =
        when (status) {
            "aberto" -> "Aberto"
            "em_andamento" -> "Em Andamento"
            "resolvido" -> "Resolvido"
            "fechado" -> "Fechado"
            else -> status
        }
