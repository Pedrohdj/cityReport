package br.dev.cityreport.data.services

import br.dev.cityreport.data.model.Category
import br.dev.cityreport.data.repository.CategoryRepository

class CategoryService(private val categoryRepository: CategoryRepository) {
    
    suspend fun insertCategory(category: Category): Result<Long> {
        return categoryRepository.insertCategory(category)
    }
    
    suspend fun getAllCategories(): List<Category> {
        return categoryRepository.getAllCategories()
    }
    
    suspend fun getCategoryById(id: Long): Category? {
        return categoryRepository.getCategoryById(id)
    }
}
