package br.dev.cityreport.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import br.dev.cityreport.data.model.Problem

@Dao
interface ProblemDao {
    @Insert
    suspend fun insertProblem(problem: Problem): Long
    @Query("SELECT * FROM problemas WHERE id = :problemId")
    suspend fun findProblemById(problemId: Long): Problem?
    @Query("SELECT * FROM problemas WHERE usuario_id = :userId")
    suspend fun findAllProblemsByUsuarioId(userId: Long): List<Problem>
    @Update(onConflict = OnConflictStrategy.REPLACE)
    suspend fun updateProblem(problem: Problem): Int

}