package br.dev.cityreport.data.repository

import br.dev.cityreport.data.local.dao.UserDao
import br.dev.cityreport.data.model.User

class UserRepository(private val userDao: UserDao) {

    suspend fun registerUser(user: User): Result<Long> {
        return try {
            val existingUser = userDao.getUserByEmail(user.email)
            if (existingUser != null) {
                Result.failure(Exception("Este e-mail já está cadastrado."))
            } else {
                val userId = userDao.insertUser(user)
                if (userId > 0) {
                    Result.success(userId)
                } else {
                    Result.failure(Exception("Falha ao registrar usuário."))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    public suspend fun getUserByEmail(email: String): User? {
        return userDao.getUserByEmail(email)
    }
}