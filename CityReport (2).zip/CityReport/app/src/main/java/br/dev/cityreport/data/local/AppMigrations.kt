package br.dev.cityreport.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

class AppMigrations {
    companion object {
        private val Migrations: List<String> = listOf(
            "INSERT INTO categorias VALUES(1,'Iluminação','Problemas com iluminação pública');\n" +
                    "INSERT INTO categorias VALUES(2,'Buraco na Rua','Buracos e problemas no asfalto');\n" +
                    "INSERT INTO categorias VALUES(3,'Limpeza','Problemas de limpeza urbana');\n" +
                    "INSERT INTO categorias VALUES(4,'Sinalização','Problemas com placas e sinalização');"
        )

        public fun getMigrations(): List<Migration> = Migrations.map { migration ->
            object : Migration(1, 2) {
                override fun migrate(database: SupportSQLiteDatabase) {
                    database.execSQL(migration)
                }
            }
        }

    }
}