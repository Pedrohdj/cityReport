package br.dev.cityreport.data.services

import br.dev.cityreport.data.model.User
import br.dev.cityreport.data.repository.UserRepository

class AuthService(private val userRepository: UserRepository) {

    companion object{
        private var loggedUser: User? = null
    }    suspend fun register(name: String, email: String, password: String): Boolean {
        return try {
            val user = User(nome = name, email = email, senha = password)
            val result = userRepository.registerUser(user)
            result.isSuccess
        } catch (e: Exception) {
            false
        }
    }

    fun getCurrentUser(): User? {
        return loggedUser
    }

    suspend fun login(email: String, password: String): Boolean {
        return try {
            val user = userRepository.getUserByEmail(email)
            if(user==null){
                return false
            }
            if (user.senha != password) {
                return false
            }
            loggedUser = user
            return true
        } catch (e: Exception) {
            return false
        }
    }
    
}