package br.dev.cityreport.data.model

import androidx.room.TypeConverter
import java.util.*

class PhotoListConverter {
    @TypeConverter
    fun fromList(list: List<ByteArray>?): String? {
        if (list == null) return null
        return list.joinToString(separator = ";") { Base64.getEncoder().encodeToString(it) }
    }

    @TypeConverter
    fun toList(data: String?): List<ByteArray> {
        if (data.isNullOrEmpty()) return emptyList()
        return data.split(';').mapNotNull {
            try {
                Base64.getDecoder().decode(it)
            } catch (e: Exception) {
                null
            }
        }
    }
}
