package br.dev.cityreport.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import br.dev.cityreport.data.model.Category

@Dao
interface CategoryDao {
    @Insert
    suspend fun insertCategory(category: Category): Long
    @Query("SELECT * FROM categorias")
    suspend fun findAllCategories(): List<Category>
}