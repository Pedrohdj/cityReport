package br.dev.cityreport.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import br.dev.cityreport.data.model.Problem
import br.dev.cityreport.data.services.AuthService
import br.dev.cityreport.data.services.CategoryService
import br.dev.cityreport.data.services.ProblemService
import br.dev.cityreport.views.components.AddProblemDialog
import br.dev.cityreport.views.components.ProblemCard
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProblemListScreen(
        problemService: ProblemService,
        authService: AuthService,
        categoryService: CategoryService,
        onProblemClick: (Problem) -> Unit = {}
) {
    var problems by remember { mutableStateOf<List<Problem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    // Carrega os problemas quando o composable é criado
    LaunchedEffect(Unit) {
        loadProblems(problemService, authService) { result ->
            when (result) {
                is ProblemsResult.Success -> {
                    problems = result.problems
                    isLoading = false
                    errorMessage = null
                }
                is ProblemsResult.Error -> {
                    isLoading = false
                    errorMessage = result.message
                }
            }
        }
    }

    Scaffold(
            topBar = { TopAppBar(title = { Text("CityReport", fontWeight = FontWeight.Bold) }) },
            floatingActionButton = {
                FloatingActionButton(
                        onClick = { showAddDialog = true },
                        containerColor = MaterialTheme.colorScheme.primary
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Adicionar Problema")
                }
            }
    ) { innerPadding ->
        Box(
                modifier =
                        Modifier.fillMaxSize()
                                .background(MaterialTheme.colorScheme.background)
                                .padding(innerPadding)
        ) {
            when {
                isLoading -> {
                    LoadingContent()
                }
                errorMessage != null -> {
                    ErrorContent(
                            message = errorMessage!!,
                            onRetryClick = {
                                isLoading = true
                                errorMessage = null
                                coroutineScope.launch {
                                    loadProblems(problemService, authService) { result ->
                                        when (result) {
                                            is ProblemsResult.Success -> {
                                                problems = result.problems
                                                isLoading = false
                                                errorMessage = null
                                            }
                                            is ProblemsResult.Error -> {
                                                isLoading = false
                                                errorMessage = result.message
                                            }
                                        }
                                    }
                                }
                            }
                    )
                }
                problems.isEmpty() -> {
                    EmptyContent()
                }
                else -> {
                    ProblemsContent(
                            problems = problems,
                            categoryService = categoryService,
                            onProblemClick = onProblemClick
                    )
                }
            }
        }

        // Dialog para adicionar problema
        val currentUser = authService.getCurrentUser()
        if (currentUser != null) {
            AddProblemDialog(
                    isVisible = showAddDialog,
                    categoryService = categoryService,
                    userId = currentUser.id,
                    onDismiss = { showAddDialog = false },
                    onConfirm = { problem ->
                        coroutineScope.launch {
                            try {
                                val result = problemService.registerProblem(problem)
                                if (result.isSuccess) {
                                    showAddDialog = false
                                    // Recarrega a lista de problemas
                                    loadProblems(problemService, authService) { loadResult ->
                                        when (loadResult) {
                                            is ProblemsResult.Success -> {
                                                problems = loadResult.problems
                                            }
                                            is ProblemsResult.Error -> {
                                                errorMessage = loadResult.message
                                            }
                                        }
                                    }
                                }
                            } catch (e: Exception) {
                                errorMessage = "Erro ao cadastrar problema: ${e.message}"
                            }
                        }
                    }
            )
        }
    }
}

@Composable
private fun LoadingContent() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                    text = "Carregando problemas...",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp
            )
        }
    }
}

@Composable
private fun ErrorContent(message: String, onRetryClick: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(32.dp)
        ) {
            Text(
                    text = "Erro ao carregar problemas",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.error,
                    textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                    text = message,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = onRetryClick) { Text("Tentar Novamente") }
        }
    }
}

@Composable
private fun EmptyContent() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(32.dp)
        ) {
            Text(
                    text = "Nenhum problema encontrado",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                    text =
                            "Você ainda não reportou nenhum problema. Toque no botão + para adicionar um novo problema.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ProblemsContent(
        problems: List<Problem>,
        categoryService: CategoryService,
        onProblemClick: (Problem) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 8.dp)) {
        items(problems) { problem ->
            ProblemCard(
                    problem = problem,
                    categoryService = categoryService,
                    onClick = { onProblemClick(problem) }
            )
        }
    }
}

// Classe selada para representar o resultado do carregamento
private sealed class ProblemsResult {
    data class Success(val problems: List<Problem>) : ProblemsResult()
    data class Error(val message: String) : ProblemsResult()
}

// Função suspensa para carregar os problemas
private suspend fun loadProblems(
        problemService: ProblemService,
        authService: AuthService,
        onResult: (ProblemsResult) -> Unit
) {
    try {
        val currentUser = authService.getCurrentUser()
        if (currentUser != null) {
            val problems = problemService.findAllProblemsByUsuarioId(currentUser.id.toLong())
            onResult(ProblemsResult.Success(problems))
        } else {
            onResult(ProblemsResult.Error("Usuário não autenticado"))
        }
    } catch (e: Exception) {
        onResult(ProblemsResult.Error(e.message ?: "Erro desconhecido"))
    }
}
